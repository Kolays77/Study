int solve(const char *, const char *, char *, const char *);
int make_string(char *);
int make_words(char *, const char *sparse);

int make_words_ex(char *, const char *sparse);
int delete_sparse(char *, const char *);
