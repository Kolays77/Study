int solve(const char *, const char *, char *, const char *);
int make_string(char *);
void print_array(char **, int);
