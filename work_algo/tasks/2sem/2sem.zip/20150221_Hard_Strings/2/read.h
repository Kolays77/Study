int solve(const char *, const char *, const char *, const char *);
void print_array(char **, int);
