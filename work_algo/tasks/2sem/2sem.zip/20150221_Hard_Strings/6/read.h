int make_string(char *);
int make_examplar(char *);
int compare(char *,
			char *);
int solve(const char *,
		  const char *, 
		  char *);
