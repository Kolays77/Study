int read_matrix(const char *, double *, int, int);
double init_element1(int, int);
double init_element2(int, int);
void init_matrix(double *, int, int, int);
void print_matrix(double *, int, int);
void return_error(int, const char *);
