void product(double *, double *, double *, int, int, int);
