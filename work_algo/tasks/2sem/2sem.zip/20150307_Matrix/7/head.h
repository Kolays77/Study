int swap_coloumns(double *, int, int, int, int);
