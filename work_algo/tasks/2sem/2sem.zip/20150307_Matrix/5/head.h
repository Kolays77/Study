void dif_matrix(double *, int);
