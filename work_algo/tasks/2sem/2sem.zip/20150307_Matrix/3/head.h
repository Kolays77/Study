void transposition(double *, int);
