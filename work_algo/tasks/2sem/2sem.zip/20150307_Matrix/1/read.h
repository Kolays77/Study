int read_matrix(const char *, double *, int, int);
double init_element(int, int);
void init_matrix(double *, int, int);
void print_matrix(double *, int, int);
