int is_symmetric(double *, int);
