double trace(double *, int);
