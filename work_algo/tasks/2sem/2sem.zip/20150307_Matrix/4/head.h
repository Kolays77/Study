void sum_matrix(double *, int);
