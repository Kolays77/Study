void product(double *, double *, int, int);
