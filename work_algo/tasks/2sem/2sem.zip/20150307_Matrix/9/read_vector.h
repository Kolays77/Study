int read_vector(const char *, double *, int);
void print_vector(double *, int);
void init_vector(double *, int);
double init_(int);
