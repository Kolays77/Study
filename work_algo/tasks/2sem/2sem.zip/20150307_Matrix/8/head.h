int first_type(double *, int, int, int, int, double);
