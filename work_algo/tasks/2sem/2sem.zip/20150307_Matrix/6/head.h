int swap_strings(double *, int, int, int, int);
