int read_array(const char *, char **, int);
void print_array(char **, int);
