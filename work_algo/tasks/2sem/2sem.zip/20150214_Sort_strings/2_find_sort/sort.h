int comparator(const char *, const char *);
void find_sort(char **, int, int (*)(const char *, const char *)); 
