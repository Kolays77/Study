int comparator(const char *, const char *);
void quick_sort(char **, int, int (*)(const char *, const char *)); 
void swap(char **, char **);
