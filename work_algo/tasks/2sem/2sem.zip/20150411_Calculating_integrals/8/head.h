double function(double x);
void calculate_integral(double (*f)(double),
						double a,
						double b,
						double eps);
