double function(double x);
double differential2(double x);
void calculate_differential2(double (*f)(double),
							  double x,
							  double h);
