double function(double x);
int sign(double x);
void calculate_integral(double (*f)(double),
						double a,
						double b,
						int n);
