double function(double x);
double differential(double x);
void calculate_differential(double (*f)(double),
							  double x,
							  double h);
