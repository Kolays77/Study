int make_string(char *str);
int delete_spaces(char **current_char, char *sign, char *found, FILE *fp2);
int solve(const char *input,
		  const char *output);
