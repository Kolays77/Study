int make_string(char *str);
int solve(const char *input,
		  const char *output);
