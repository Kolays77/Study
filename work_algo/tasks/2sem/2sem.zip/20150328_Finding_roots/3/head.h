double function(double x0);
int find_root(double left_board,
              double right_board,
              double (*f)(double),
              double eps,
              double *answer);
