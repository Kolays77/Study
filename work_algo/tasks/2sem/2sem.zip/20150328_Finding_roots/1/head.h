double function(double x0);
int find_root(double (*f)(double),
              double left_board,
              double right_board,
              double eps,
              double *answer);
