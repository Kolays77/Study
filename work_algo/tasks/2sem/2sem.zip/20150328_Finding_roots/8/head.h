double function(double x0);
int find_max(double left_board,
			  double right_board,
              double (*f)(double),
              double eps,
              double *x);
