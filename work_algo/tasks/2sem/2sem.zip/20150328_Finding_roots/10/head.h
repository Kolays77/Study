double function(double x0);
int find_max(double x0,
              double x2,
              double x1,
              double (*f)(double),
              double eps,
              double *answer);
