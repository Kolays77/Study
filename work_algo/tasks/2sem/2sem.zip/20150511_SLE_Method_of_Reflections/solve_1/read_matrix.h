int read_matrix(const char *, double *, int);
double init_element(int, int);
void init_matrix(double *, int);
void print_matrix(double *, int, int);
void return_error(int, const char *);
