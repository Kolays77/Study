void product(double *, double *, double *, int);
double dot_product(double *, double *, int);
double solve(double *, double *, double *, int, int);
