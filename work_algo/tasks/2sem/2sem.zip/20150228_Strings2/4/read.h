int read_array(const char *, char **, int);
int make_string(char *);
