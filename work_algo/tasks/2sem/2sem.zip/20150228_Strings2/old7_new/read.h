int make_string(char *);
int make_examplar(char *,
                  char *);
int compare(char *,
			char *,
			char *);
int solve(const char *,
		  const char *, 
		  char *,
		  char *);
