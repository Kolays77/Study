int make_string(char *);
int make_examplar(char *, char *);
int solve(const char *,
		  const char *, 
		  char *);
int compare(char *str1, char *str2, char *flags);
