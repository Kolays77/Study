void make_string(char *, char *);
int solve(const char *,
		  const char *, 
		  char *,
		  char *);
