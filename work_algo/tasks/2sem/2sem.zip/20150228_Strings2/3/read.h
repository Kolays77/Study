void make_string(char *);
int solve(const char *,
		  const char *, 
		  char *);
