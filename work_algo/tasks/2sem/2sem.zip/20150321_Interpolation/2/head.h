int make_f(double *x, double *func, int n);
double calculate_answer(double *x, double *func, int n, double x0);
