double get_int_exp(int deg);
double get_exp(double x, double eps);
