int solve(double *x, double *func, int n, double x0);
