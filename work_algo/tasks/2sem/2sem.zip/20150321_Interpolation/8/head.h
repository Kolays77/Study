double get_ln(double x, double eps);
