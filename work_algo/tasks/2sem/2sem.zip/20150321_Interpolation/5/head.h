double get_sin(double x, double eps);
double get_cos(double x, double eps);
