int make_f(double *x, double *func, double *dif, int n);
double calculate_answer(double *x, double *func, double *dif, int n, double x0);
