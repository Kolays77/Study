int read(const char *name, double *x, double *y, int n);
void return_error(int result, const char *name);
void print_function(double *x, double *y, int n);
