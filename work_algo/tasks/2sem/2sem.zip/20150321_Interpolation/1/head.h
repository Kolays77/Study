double solve(double *x, double *y, int n, double x0);
