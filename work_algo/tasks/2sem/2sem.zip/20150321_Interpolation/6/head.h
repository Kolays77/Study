double get_cos(double x, double eps);
